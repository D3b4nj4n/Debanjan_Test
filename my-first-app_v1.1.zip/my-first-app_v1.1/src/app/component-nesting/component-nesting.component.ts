import { Component, OnInit } from '@angular/core';

@Component({
  // selector: '.app-component-nesting',
  templateUrl: './component-nesting.component.html',
  // styleUrls: ['./component-nesting.component.css']
  styles: [`
  .comp-nest {
    padding : 20px;
    color: blue;
  }
  `]
})
export class ComponentNestingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentNestingComponent } from './component-nesting.component';

describe('ComponentNestingComponent', () => {
  let component: ComponentNestingComponent;
  let fixture: ComponentFixture<ComponentNestingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComponentNestingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentNestingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
